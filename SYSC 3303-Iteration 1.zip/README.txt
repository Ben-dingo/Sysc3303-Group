Group 6 project iteration 1 


Instructions for running iteration 1:

1.	Launch project in eclipse.
2.	Main function is in threadRunner.
3.	run project and follow prompts.
4.	Quit can be entered at any time to shut down servers and close the program.
5.	If quiet is selected datagram details will not be printed, if verbose is selected it will.
6.	Next you're prompted to declare wether you desire a read or write.
7.	Finally you're asked to enter the message your wish to send in the terminal.
	(At this point only messages 10 characters or shorter can be transfered.)
8.	After a transfer is done the process begins again.