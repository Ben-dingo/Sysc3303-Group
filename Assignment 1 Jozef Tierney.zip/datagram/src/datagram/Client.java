package datagram;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class Client {

  @SuppressWarnings("resource")
public static void main(String[] args) throws IOException  {
    
    while (true) {
    	readRequest();
    	readRequest();
    	readRequest();
    	readRequest();
    	readRequest();
    }
  }
  public static void readRequest() throws IOException {
	  @SuppressWarnings("resource")
	DatagramSocket s = new DatagramSocket();
	    byte[] buf = new byte[1000];
	    DatagramPacket dp = new DatagramPacket(buf, buf.length);

	    InetAddress hostAddress = InetAddress.getByName("localhost");
	    

	      String outMessage = ("input message here");
	  buf = outMessage.getBytes();

      DatagramPacket out = new DatagramPacket(buf, buf.length, hostAddress, 9999);
      s.send(out);

      s.receive(dp);
      String rcvd = "rcvd from " + dp.getAddress() + ", " + dp.getPort() + ": "
          + new String(dp.getData(), 0, dp.getLength());
      System.out.println(rcvd);
	  
  }
}