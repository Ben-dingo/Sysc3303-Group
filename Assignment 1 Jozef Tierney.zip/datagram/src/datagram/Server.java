package datagram;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class Server {
  @SuppressWarnings("resource")
public static void main(String[] args) throws Exception {
    
    
    System.out.println("Server started");
    while (true) {
    	writeRequest("test1.txt", "octet");
    	writeRequest("test2.txt", "octet");
    	writeRequest("test3.txt", "octet");
    	writeRequest("test4.txt", "octet");
    	writeRequest("test5.txt", "octet");
      
    }
  }
  	@SuppressWarnings("resource")
	public static void writeRequest(String filename, String mode) throws IOException {
  		byte[] buf = new byte[1000];
  	    DatagramPacket dgp = new DatagramPacket(buf, buf.length);
  	    DatagramSocket sk;
  	    sk = new DatagramSocket(23);
  	    
  	    
  	    
  		sk.receive(dgp);
        String rcvd = new String(dgp.getData(), 0, dgp.getLength()) + ", from address: "
            + dgp.getAddress() + ", port: " + dgp.getPort();
        System.out.println(rcvd);
        
        buf = (02 + filename + 0 + mode + 0).getBytes();
        DatagramPacket out = new DatagramPacket(buf, buf.length, dgp.getAddress(), dgp.getPort());
        sk.send(out);
  	}
}